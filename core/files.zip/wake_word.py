"""
core/wake_word.py
Wake word detection for Cracka AI.
Supports: "cracka", "hey cracka", "ok cracka", "jarvis"
"""

import speech_recognition as sr
import os

WAKE_WORDS = ["cracka", "hey cracka", "ok cracka", "jarvis", "hey jarvis"]

recognizer = sr.Recognizer()
recognizer.energy_threshold = 300
recognizer.dynamic_energy_threshold = True
recognizer.pause_threshold = 0.5


def listen_wake_word() -> bool:
    """
    Continuously listens for wake word.
    Returns True when detected.
    """
    with sr.Microphone() as source:
        print("\033[90m[Waiting for wake word: 'Cracka'...]\033[0m")
        recognizer.adjust_for_ambient_noise(source, duration=0.5)

        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=3)
            text = recognizer.recognize_google(audio, language="en-IN").lower()
            print(f"\033[90m[Heard]: {text}\033[0m")

            for word in WAKE_WORDS:
                if word in text:
                    return True

        except sr.WaitTimeoutError:
            pass
        except sr.UnknownValueError:
            pass
        except sr.RequestError as e:
            print(f"[WakeWord] STT error: {e}")
        except Exception as e:
            print(f"[WakeWord] Error: {e}")

    return False


def listen_wake_word_pvporcupine() -> bool:
    """
    Alternative: Offline wake word using Porcupine (pvporcupine).
    Much faster and more accurate. Requires Picovoice API key.
    Set PICOVOICE_KEY in environment.
    """
    try:
        import pvporcupine
        import pyaudio
        import struct

        key = os.environ.get("PICOVOICE_KEY", "")
        if not key:
            return listen_wake_word()

        porcupine = pvporcupine.create(
            access_key=key,
            keywords=["jarvis", "hey google"]
        )
        pa = pyaudio.PyAudio()
        stream = pa.open(
            rate=porcupine.sample_rate,
            channels=1,
            format=pyaudio.paInt16,
            input=True,
            frames_per_buffer=porcupine.frame_length
        )

        while True:
            pcm = stream.read(porcupine.frame_length)
            pcm = struct.unpack_from("h" * porcupine.frame_length, pcm)
            idx = porcupine.process(pcm)
            if idx >= 0:
                stream.close()
                pa.terminate()
                porcupine.delete()
                return True

    except ImportError:
        return listen_wake_word()
    except Exception as e:
        print(f"[Porcupine] Error: {e}")
        return listen_wake_word()
