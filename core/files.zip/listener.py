"""
core/listener.py
Speech recognition for Cracka AI.
Supports Google STT (online) and Vosk (offline fallback).
"""

import speech_recognition as sr
import os

recognizer = sr.Recognizer()
recognizer.pause_threshold = 0.6
recognizer.energy_threshold = 300
recognizer.dynamic_energy_threshold = True


def listen(timeout: int = 8, phrase_limit: int = 10) -> str:
    """
    Listen for voice input and return recognized text.
    Returns empty string on failure.
    """
    with sr.Microphone() as source:
        print("\033[90m[Listening...]\033[0m")
        recognizer.adjust_for_ambient_noise(source, duration=0.3)

        try:
            audio = recognizer.listen(
                source,
                timeout=timeout,
                phrase_time_limit=phrase_limit
            )
        except sr.WaitTimeoutError:
            return ""

    # Try Google STT first
    try:
        text = recognizer.recognize_google(audio, language="en-IN")
        print(f"\033[93mBoss:\033[0m {text}")
        return text.lower().strip()
    except sr.UnknownValueError:
        return ""
    except sr.RequestError:
        # Offline fallback
        return _vosk_fallback(audio)


def _vosk_fallback(audio) -> str:
    """
    Offline recognition using Vosk if Google STT fails.
    Vosk is OPTIONAL — if not installed, returns empty string silently.

    To enable offline mode:
      1. pip install vosk
      2. Download model from https://alphacephei.com/vosk/models
         (use: vosk-model-small-en-us-0.15)
      3. Extract into:  models/vosk-model-small-en-us/
    """
    try:
        import vosk  # Check if installed
    except ImportError:
        # Vosk not installed — that's fine, Google STT is primary
        return ""

    try:
        from vosk import Model, KaldiRecognizer
        import json
        import wave
        import tempfile

        model_path = "models/vosk-model-small-en-us"
        if not os.path.exists(model_path):
            # Model not downloaded yet — skip silently
            return ""

        model = Model(model_path)
        rec = KaldiRecognizer(model, 16000)

        # Save audio to temp WAV file
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(audio.get_wav_data())
            tmp = f.name

        with wave.open(tmp, "rb") as wf:
            while True:
                data = wf.readframes(4000)
                if not data:
                    break
                rec.AcceptWaveform(data)

        os.unlink(tmp)
        result = json.loads(rec.FinalResult())
        return result.get("text", "").strip()

    except Exception as e:
        print(f"[Vosk] Error: {e}")
        return ""


def listen_for_text(prompt: str = "") -> str:
    """Listen once with optional spoken prompt."""
    if prompt:
        from core.voice_engine import speak
        speak(prompt)
    return listen()
